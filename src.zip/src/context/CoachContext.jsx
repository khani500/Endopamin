import { createContext, useCallback, useContext, useEffect, useState } from 'react';

const STORAGE_KEY = 'endopamin_coach_conversation';

const CoachContext = createContext(null);

function loadStoredHistory() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function lastAssistantMessage(history) {
  for (let i = history.length - 1; i >= 0; i -= 1) {
    if (history[i].role === 'assistant') return history[i].content;
  }
  return null;
}

export function getDailyGreeting(profile) {
  const hour = new Date().getHours();
  const name = profile?.display_name || profile?.name || 'Athlete';
  if (hour < 12) return `Morning ${name}. Ready to work?`;
  if (hour < 17) return `${name}, afternoon session. Let's go.`;
  return `Evening ${name}. Finish strong today.`;
}

export function CoachProvider({ children }) {
  const [conversationHistory, setConversationHistory] = useState(() => loadStoredHistory());
  const [lastCoachMessage, setLastCoachMessage] = useState(() => lastAssistantMessage(loadStoredHistory()));

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(conversationHistory));
    } catch {
      // ignore quota errors
    }
  }, [conversationHistory]);

  const addMessage = useCallback((role, content) => {
    const msg = { role, content, timestamp: Date.now() };
    setConversationHistory(prev => {
      const next = [...prev, msg];
      return next;
    });
    if (role === 'assistant') {
      setLastCoachMessage(content);
    }
    return msg;
  }, []);

  const clearHistory = useCallback(() => {
    setConversationHistory([]);
    setLastCoachMessage(null);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
  }, []);

  return (
    <CoachContext.Provider
      value={{
        conversationHistory,
        lastCoachMessage,
        setConversationHistory,
        setLastCoachMessage,
        addMessage,
        clearHistory,
      }}
    >
      {children}
    </CoachContext.Provider>
  );
}

export function useCoachChat() {
  const ctx = useContext(CoachContext);
  if (!ctx) {
    throw new Error('useCoachChat must be used within CoachProvider');
  }
  return ctx;
}
