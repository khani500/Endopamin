import { askGemini, buildCoachSystemPrompt, sendCoachMessage } from '../lib/gemini';
import { getCoach } from '../config/coaches';

function firstName(name) {
  return String(name || 'Champion').trim().split(/\s+/)[0] || 'Champion';
}

export function buildUserProfileContext(profile = {}, fallbackName = 'Champion', mode = 'chat') {
  return buildCoachSystemPrompt(normalizeProfile(profile, fallbackName), mode);
}

function normalizeProfile(userProfile = {}, fallbackName = 'Champion') {
  const profile = userProfile && typeof userProfile === 'object' ? userProfile : {};
  return {
    ...profile,
    display_name: profile.display_name || fallbackName,
    name: profile.display_name || fallbackName,
  };
}

export const getDailyMessage = async (coachId, userContext) => {
  const userName = firstName(userContext?.name);
  const profile = normalizeProfile(userContext, userName);
  const hour = new Date().getHours();
  const timeOfDay = hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening';
  const streak = userContext?.streak || 0;
  const goal = userContext?.goal || 'training';

  const prompt = `Write a ${timeOfDay} message for ${userName}.
Streak: ${streak} days. Goal: ${goal}.
One sentence about what to do today (training or recovery).
One sentence of real coach energy — not hype, just truth.
No lists. No greetings. Just speak directly.`;

  try {
    return await askGemini(prompt, buildCoachSystemPrompt(profile, 'chat'));
  } catch (error) {
    console.error('Daily message failed:', error);
    return `${userName}, one consistent session today beats perfect planning tomorrow.`;
  }
};

export const getCheckInResponse = async (coachId, userName, energy, sleep, userProfile = {}) => {
  const coach = getCoach(coachId);
  const profile = normalizeProfile(userProfile, userName);

  const prompt = `${firstName(userName)} checked in. Energy: ${energy}/5. Sleep: ${sleep ? 'good' : 'poor'}.
Give a specific training recommendation for today (exercises or session type, duration, intensity). No generic hype.`;

  try {
    return await askGemini(prompt, buildCoachSystemPrompt(profile));
  } catch (error) {
    console.error('Gemini check-in failed:', error);
    return `${coach.name}: ${energy <= 2 || !sleep ? 'Do 20-30 min mobility + walk today.' : 'Run your planned strength session with controlled tempo.'}`;
  }
};

export const getProgressInsight = async (coachId, userName, metrics, userProfile = {}) => {
  const coach = getCoach(coachId);
  const profile = normalizeProfile(userProfile, userName);
  const { weightChange, workoutsThisWeek, topExercise, streak } = metrics;

  const prompt = `Analyze progress for ${firstName(userName)}:
- Weight change: ${weightChange}kg this week
- Workouts: ${workoutsThisWeek}/7
- Best lift progress: ${topExercise}
- Streak: ${streak} days
Give one specific insight and one actionable next step.`;

  try {
    return await askGemini(prompt, buildCoachSystemPrompt(profile));
  } catch (error) {
    console.error('Gemini progress insight failed:', error);
    return `${coach.name}: Pick one metric to improve this week and track it every session.`;
  }
};

export const generateWorkoutPlan = async (coachId, userProfile) => {
  const profile = normalizeProfile(userProfile);
  const { goal, experience, daysPerWeek, timeAvailable, injuries } = userProfile;

  const prompt = `Create a ${daysPerWeek}-day workout plan.
Goal: ${goal}
Experience: ${experience}
Time per session: ${timeAvailable}
Injuries: ${injuries || 'none'}

Return as JSON:
{
  "plan": [
    { "day": "Monday", "type": "Strength", "duration": 45, "exercises": [{ "name": "Bench Press", "sets": 3, "reps": 8, "rest": 90 }] }
  ]
}
Return ONLY JSON.`;

  try {
    const response = await askGemini(prompt, buildCoachSystemPrompt(profile));
    return JSON.parse(response.replace(/```json|```/g, '').trim());
  } catch (error) {
    console.error('Gemini workout plan failed:', error);
    return null;
  }
};

export const chatWithCoach = async (
  coachId,
  userName,
  message,
  conversationHistory = [],
  userProfile = {},
  mode = 'chat',
) => {
  const coach = getCoach(coachId);
  const profile = normalizeProfile(
    typeof userProfile === 'string' ? { gender: userProfile, display_name: userName } : userProfile,
    userName,
  );

  const history = conversationHistory.map(item => ({
    role: item.role === 'user' ? 'user' : 'assistant',
    content: item.content,
  }));

  try {
    return await sendCoachMessage(message, {
      userProfile: profile,
      conversationHistory: history,
      mode: mode === 'voice' ? 'voice' : 'chat',
    });
  } catch (error) {
    console.error('Gemini coach chat failed:', error);
    const name = firstName(userName);
    return `${coach.name}: I couldn't reach the AI server right now, ${name}. While I'm back: tell me your goal for today and I'll give you a concrete session structure.`;
  }
};
