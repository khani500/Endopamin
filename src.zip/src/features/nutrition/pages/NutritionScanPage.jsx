import { useMemo } from 'react';
import { useNutritionStore } from '../store/nutritionStore';
import { FoodScanner } from '../components/FoodScanner';
import { FoodDatabaseSearch } from '../components/FoodDatabaseSearch';

const MACRO_META = [
  { key: 'protein', label: 'Protein', color: '#FFCC00' },
  { key: 'carbs', label: 'Carbs', color: '#FF9500' },
  { key: 'fat', label: 'Fat', color: '#FF3B30' },
];

function polarToCartesian(cx, cy, radius, angleInDegrees) {
  const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180;
  return {
    x: cx + radius * Math.cos(angleInRadians),
    y: cy + radius * Math.sin(angleInRadians),
  };
}

function describeArc(cx, cy, radius, startAngle, endAngle) {
  const start = polarToCartesian(cx, cy, radius, endAngle);
  const end = polarToCartesian(cx, cy, radius, startAngle);
  const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1';

  return [
    `M ${cx} ${cy}`,
    `L ${start.x} ${start.y}`,
    `A ${radius} ${radius} 0 ${largeArcFlag} 0 ${end.x} ${end.y}`,
    'Z',
  ].join(' ');
}

function useTodayMacroData() {
  const foodLog = useNutritionStore(s => s.foodLog);

  return useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    const totals = foodLog
      .filter(entry => String(entry.at || '').startsWith(today))
      .reduce(
        (sum, entry) => ({
          protein: sum.protein + (Number(entry.protein) || 0),
          carbs: sum.carbs + (Number(entry.carbs) || 0),
          fat: sum.fat + (Number(entry.fat) || 0),
        }),
        { protein: 0, carbs: 0, fat: 0 },
      );
    const totalGrams = totals.protein + totals.carbs + totals.fat;
    const macros = MACRO_META.map(macro => {
      const grams = Math.round(totals[macro.key] || 0);
      const percent = totalGrams > 0 ? Math.round((grams / totalGrams) * 100) : 0;
      return { ...macro, grams, percent };
    });
    const segments = macros.reduce((items, macro) => {
      const startAngle = items.length ? items[items.length - 1].endAngle : 0;
      const endAngle = startAngle + macro.percent * 3.6;
      return [...items, { ...macro, startAngle, endAngle }];
    }, []);

    return { macros, segments, totalGrams: Math.round(totalGrams) };
  }, [foodLog]);
}

export function SmartMacroPieChart() {
  const { macros, segments, totalGrams } = useTodayMacroData();

  return (
    <section className="np-card">
      <div className="np-chart-title-row">
        <div>
          <p className="np-brand" style={{ marginBottom: 4 }}>Smart Macros</p>
          <h3 style={{ margin: 0 }}>Macro distribution</h3>
        </div>
        <span className="np-badge">Today</span>
      </div>

      <div className="np-pie-wrap">
        <svg width="168" height="168" viewBox="0 0 168 168" aria-label="Macro nutrient pie chart">
          <circle cx="84" cy="84" r="72" fill="#0A0A0A" />
          {segments.map(macro => {
            const path = describeArc(84, 84, 72, macro.startAngle, macro.endAngle);
            return <path key={macro.key} d={path} fill={macro.color} />;
          })}
          <circle cx="84" cy="84" r="36" fill="#111113" />
          <text x="84" y="80" textAnchor="middle" fill="#ffffff" fontSize="18" fontWeight="900">{totalGrams}g</text>
          <text x="84" y="99" textAnchor="middle" fill="rgba(255,255,255,0.45)" fontSize="10" fontWeight="700">TOTAL</text>
        </svg>

        <div className="np-pie-legend">
          {macros.map(macro => (
            <div key={macro.key} className="np-pie-legend-row">
              <span className="np-pie-dot" style={{ background: macro.color }} />
              <span>{macro.label}</span>
              <strong>{macro.grams}g</strong>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function MacroMatrixGrid() {
  const { macros } = useTodayMacroData();

  return (
    <section className="np-matrix-grid">
      {macros.map(macro => (
        <div key={macro.key} className="np-matrix-card" style={{ borderColor: `${macro.color}66` }}>
          <p style={{ color: macro.color }}>{macro.label.toUpperCase()}</p>
          <strong>{macro.grams}g</strong>
          <span>{macro.percent}%</span>
        </div>
      ))}
    </section>
  );
}

export default function NutritionScanPage() {
  const addFoodEntry = useNutritionStore(s => s.addFoodEntry);

  return (
    <main className="np-main">
      <FoodScanner
        onSearchDatabase={() => document.getElementById('food-database')?.scrollIntoView({ behavior: 'smooth' })}
        onAnalyzed={r =>
          addFoodEntry({
            name: r?.name || r?.food_name || r?.label || 'Scanned meal',
            kcal: Number(r?.calculated_total_calories ?? r?.kcal ?? r?.calories) || 0,
            protein: Number(r?.calculated_total_protein_g ?? r?.protein ?? r?.protein_g) || 0,
            carbs: Number(r?.calculated_total_carbs_g ?? r?.carbs ?? r?.carbs_g) || 0,
            fat: Number(r?.calculated_total_fat_g ?? r?.fat ?? r?.fat_g) || 0,
          })
        }
      />
      <FoodDatabaseSearch onAddEntry={addFoodEntry} />
      <SmartMacroPieChart />
      <MacroMatrixGrid />
    </main>
  );
}
