import { FOOD_SCAN_PROMPT, generateGeminiVision } from '../lib/gemini';
import { FOOD_SCAN_GENERATION_CONFIG } from '../lib/foodScanConfig';

export async function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(String(reader.result).split(',')[1] || '');
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

async function canvasToBlob(canvas, type = 'image/jpeg', quality = 0.82) {
  return new Promise(resolve => canvas.toBlob(resolve, type, quality));
}

async function normalizeImageBlob(blob) {
  if (!blob) throw new Error('No image file was provided.');

  try {
    const bitmap = await createImageBitmap(blob);
    const maxSide = 1024;
    const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
    const width = Math.max(1, Math.round(bitmap.width * scale));
    const height = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Could not create image canvas.');
    ctx.drawImage(bitmap, 0, 0, width, height);
    bitmap.close?.();
    return (await canvasToBlob(canvas)) || blob;
  } catch (error) {
    console.warn('Could not normalize image to JPEG, using original blob:', error);
    return blob;
  }
}

export async function imageToGeminiPayload(blob) {
  const normalizedBlob = await normalizeImageBlob(blob);
  const base64 = await blobToBase64(normalizedBlob);
  const mimeType = normalizedBlob.type || 'image/jpeg';
  return {
    base64,
    mimeType,
    byteSize: normalizedBlob.size || blob.size || 0,
    originalMimeType: blob.type || 'unknown',
  };
}

function stripMarkdownCodeFence(text) {
  return String(text || '')
    .trim()
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/i, '')
    .replace(/```(?:json)?/gi, '')
    .trim();
}

function extractJson(text) {
  const clean = stripMarkdownCodeFence(text);
  const start = clean.indexOf('{');
  const end = clean.lastIndexOf('}');
  if (start === -1 || end === -1 || end <= start) return null;
  return clean.slice(start, end + 1);
}

function normalizeItem(item) {
  return {
    name: String(item.name || item.itemName || 'Food'),
    estimatedWeight: Number(item.estimatedWeight ?? item.estimatedWeightGrams ?? item.weight_g) || 0,
    weightUnit: String(item.weightUnit || 'g'),
    calories: Number(item.calories) || 0,
    protein: Number(item.protein ?? item.protein_g) || 0,
    carbs: Number(item.carbs ?? item.carbs_g) || 0,
    fat: Number(item.fat ?? item.fat_g) || 0,
    fiber: Number(item.fiber ?? item.fiber_g) || 0,
    confidence: String(item.confidence || 'medium').toLowerCase(),
  };
}

function sumItems(items) {
  return items.reduce(
    (sum, item) => ({
      calories: sum.calories + item.calories,
      protein: sum.protein + item.protein,
      carbs: sum.carbs + item.carbs,
      fat: sum.fat + item.fat,
      fiber: sum.fiber + item.fiber,
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 },
  );
}

export function normalizeFoodResult(raw) {
  if (!raw || typeof raw !== 'object') return null;

  const items = Array.isArray(raw.items) ? raw.items.map(normalizeItem) : [];
  const totalFromApi = raw.total && typeof raw.total === 'object' ? raw.total : null;
  const summed = sumItems(items);
  const total = {
    calories: Number(totalFromApi?.calories ?? summed.calories) || 0,
    protein: Number(totalFromApi?.protein ?? summed.protein) || 0,
    carbs: Number(totalFromApi?.carbs ?? summed.carbs) || 0,
    fat: Number(totalFromApi?.fat ?? summed.fat) || 0,
    fiber: Number(totalFromApi?.fiber ?? summed.fiber) || 0,
  };

  const estimatedWeight = items.reduce((sum, item) => sum + item.estimatedWeight, 0);
  const mealDescription = String(raw.mealDescription || raw.food_name || '').trim();
  const foodName =
    mealDescription ||
    items.map(item => item.name).filter(Boolean).join(', ') ||
    'Scanned meal';

  const proteinPct = total.calories > 0 ? Math.round(((total.protein * 4) / total.calories) * 1000) / 10 : 0;
  const carbsPct = total.calories > 0 ? Math.round(((total.carbs * 4) / total.calories) * 1000) / 10 : 0;
  const fatPct = total.calories > 0 ? Math.round(((total.fat * 9) / total.calories) * 1000) / 10 : 0;

  return {
    success: raw.success !== false,
    items,
    total,
    mealDescription: foodName,
    food_name: foodName,
    estimated_total_weight_g: estimatedWeight,
    calculated_total_calories: total.calories,
    calculated_total_protein_g: total.protein,
    calculated_total_carbs_g: total.carbs,
    calculated_total_fat_g: total.fat,
    protein_pct: proteinPct,
    carbs_pct: carbsPct,
    fat_pct: fatPct,
    scannedItems: items.map(item => ({
      itemName: item.name,
      estimatedWeightGrams: item.estimatedWeight,
    })),
    macros: {
      protein: { grams: total.protein, percentage: proteinPct },
      carbs: { grams: total.carbs, percentage: carbsPct },
      fat: { grams: total.fat, percentage: fatPct },
    },
    serving_size: estimatedWeight ? `${estimatedWeight}g total visible portion` : 'Estimated portion',
    calories: total.calories,
    protein_g: total.protein,
    carbs_g: total.carbs,
    fat_g: total.fat,
  };
}

export const scanFood = async (imageFile, { onRetry } = {}) => {
  const base64 = await blobToBase64(imageFile);
  const { text } = await generateGeminiVision({
    base64,
    prompt: FOOD_SCAN_PROMPT,
    generationConfig: FOOD_SCAN_GENERATION_CONFIG,
    onRetry,
  });
  if (!text) return null;

  try {
    const clean = stripMarkdownCodeFence(text);
    return normalizeFoodResult(JSON.parse(extractJson(clean) || clean));
  } catch {
    console.error('JSON parse error:', text);
    return null;
  }
};

export const analyzeFoodImage = async (imageFile, { signal, onRetry } = {}) => {
  const { base64, mimeType, byteSize, originalMimeType } = await imageToGeminiPayload(imageFile);
  const requestDebug = {
    keyLoaded: Boolean(import.meta.env.VITE_GEMINI_API_KEY?.trim()),
    originalMimeType,
    mimeType,
    byteSize,
    base64Length: base64.length,
  };

  if (!base64) throw new Error('No image data captured.');

  try {
    const { text, model, status, raw } = await generateGeminiVision({
      base64,
      mimeType,
      prompt: FOOD_SCAN_PROMPT,
      generationConfig: FOOD_SCAN_GENERATION_CONFIG,
      signal,
      onRetry,
    });

    const responseDebug = {
      ...requestDebug,
      model,
      status,
      rawText: text || '',
      errorMessage: raw?.error?.message || '',
    };

    console.log('Gemini Vision scanner response:', responseDebug);

    const cleanText = stripMarkdownCodeFence(text);
    const jsonText = extractJson(cleanText);
    if (!jsonText) {
      const error = new Error('Could not read nutrition data from this photo. Please try again.');
      error.details = responseDebug;
      error.userFriendly = true;
      throw error;
    }

    const normalized = normalizeFoodResult(JSON.parse(jsonText));
    if (!normalized?.items?.length) {
      const error = new Error('No food items were detected. Try a clearer photo or search the food database.');
      error.details = responseDebug;
      error.userFriendly = true;
      throw error;
    }

    return { ...normalized, debug: responseDebug };
  } catch (error) {
    if (error?.name === 'AbortError') throw error;
    console.error('Food scan failed:', error);
    const wrapped = new Error(
      error.userFriendly
        ? error.message
        : 'Food scan is temporarily unavailable. Please try again or search the food database.',
    );
    wrapped.details = error.details;
    wrapped.userFriendly = true;
    throw wrapped;
  }
};
