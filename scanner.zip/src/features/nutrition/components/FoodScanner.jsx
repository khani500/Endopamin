import { useCallback, useEffect, useRef, useState } from 'react';
import { Camera, ImagePlus, Loader2, Scan, X } from 'lucide-react';
import { GlassCard } from './GlassCard';
import { useAuth } from '../../../context/AuthContext';
import { supabase } from '../../../lib/supabase';
import { analyzeFoodImage } from '../../../services/foodScanner';

export function FoodScanner({ onAnalyzed, onSearchDatabase }) {
  const { user } = useAuth();
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const fileInputRef = useRef(null);
  const cameraInputRef = useRef(null);
  const [cameraOn, setCameraOn] = useState(false);
  const [scanFailed, setScanFailed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [result, setResult] = useState(null);
  const [coachTip, setCoachTip] = useState('');
  const [saveStatus, setSaveStatus] = useState('');
  const [retryToast, setRetryToast] = useState('');
  const abortRef = useRef(null);

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setCameraOn(false);
  }, []);

  const startCamera = useCallback(async () => {
    setScanFailed(false);
    setResult(null);

    const canUseLiveCamera =
      typeof navigator !== 'undefined' &&
      navigator.mediaDevices?.getUserMedia &&
      (window.isSecureContext || ['localhost', '127.0.0.1'].includes(window.location.hostname));

    if (!canUseLiveCamera) {
      cameraInputRef.current?.click();
      return;
    }

    try {
      const constraintOptions = [
        { video: { facingMode: { exact: 'environment' } }, audio: false },
        { video: { facingMode: { ideal: 'environment' } }, audio: false },
        { video: true, audio: false },
      ];

      let stream = null;
      let lastError = null;

      for (const constraints of constraintOptions) {
        try {
          stream = await navigator.mediaDevices.getUserMedia(constraints);
          break;
        } catch (err) {
          lastError = err;
        }
      }

      if (!stream) throw lastError || new Error('Camera unavailable.');

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        await videoRef.current.play().catch(() => undefined);
      }
      setCameraOn(true);
    } catch (err) {
      console.error('Camera start failed:', err);
      cameraInputRef.current?.click();
    }
  }, []);

  useEffect(() => () => stopCamera(), [stopCamera]);

  const captureFrameBlob = useCallback(async () => {
    const video = videoRef.current;
    if (!video || !video.videoWidth) return null;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0);
    return new Promise(resolve => canvas.toBlob(b => resolve(b), 'image/jpeg', 0.88));
  }, []);

  const handleRetryStatus = useCallback(({ message }) => {
    setRetryToast(message);
  }, []);

  const runAnalysis = async blob => {
    if (!blob) return;
    abortRef.current?.abort();
    abortRef.current = new AbortController();
    const { signal } = abortRef.current;
    setBusy(true);
    setScanFailed(false);
    setSaveStatus('');
    setRetryToast('');
    try {
      if (signal.aborted) return;
      const analyzed = await analyzeFoodImage(blob, { signal, onRetry: handleRetryStatus });
      if (!analyzed) throw new Error('Could not analyze food image.');
      setResult(analyzed);
      setRetryToast('');
      setCoachTip(
        analyzed.calculated_total_protein_g >= 30
          ? 'Good protein choice!'
          : 'Add a lean protein to balance this meal.',
      );
    } catch (e) {
      if (e.name !== 'AbortError') {
        console.error('Food scan error:', e);
        setScanFailed(true);
        setResult(null);
        setRetryToast('');
      }
    } finally {
      setBusy(false);
    }
  };

  const onShutter = async () => {
    const blob = await captureFrameBlob();
    await runAnalysis(blob);
  };

  const onFile = async e => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const url = URL.createObjectURL(file);
    setPreviewUrl(prev => {
      if (prev) URL.revokeObjectURL(prev);
      return url;
    });
    await runAnalysis(file);
  };

  const logMeal = async () => {
    if (!result) return;
    const entry = {
      name: result.food_name,
      kcal: Number(result.calculated_total_calories) || 0,
      protein: Number(result.calculated_total_protein_g) || 0,
      carbs: Number(result.calculated_total_carbs_g) || 0,
      fat: Number(result.calculated_total_fat_g) || 0,
    };
    onAnalyzed?.(entry);
    setSaveStatus('Meal added to today’s macros.');

    if (supabase && user?.id) {
      const { error: saveError } = await supabase.from('nutrition_logs').insert({
        user_id: user.id,
        meal_name: result.food_name,
        calories: entry.kcal,
        protein_g: entry.protein,
        carbs_g: entry.carbs,
        fat_g: entry.fat,
        meal_type: 'snack',
      });
      if (saveError) {
        console.error('Failed to save nutrition log:', saveError);
        setSaveStatus('Saved locally, but cloud sync failed.');
      } else {
        setSaveStatus('Meal logged and macros updated.');
      }
    } else if (!user?.id) {
      setSaveStatus('Meal added locally. Sign in to sync.');
    }
  };

  const resetScan = () => {
    setResult(null);
    setCoachTip('');
    setSaveStatus('');
    setScanFailed(false);
    setRetryToast('');
    setPreviewUrl(prev => {
      if (prev) URL.revokeObjectURL(prev);
      return null;
    });
  };

  const scrollToDatabase = () => {
    if (typeof onSearchDatabase === 'function') {
      onSearchDatabase();
      return;
    }
    document.getElementById('food-database')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <GlassCard>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Scan size={20} color="#39ff14" />
          <h3 style={{ margin: 0 }}>Food Scanner</h3>
        </div>
        {cameraOn && (
          <button type="button" className="np-back" onClick={stopCamera} aria-label="Close camera">
            <X size={16} />
          </button>
        )}
      </div>

      {retryToast && (
        <div className="mb-3 rounded-xl border border-[#FF9500]/40 bg-[#FF9500]/15 px-3 py-2 text-xs font-bold text-[#FF9500]">
          {retryToast}
        </div>
      )}

      <div className="np-camera-box np-camera-box--scan">
        {previewUrl && !cameraOn && <img src={previewUrl} alt="Preview" />}
        <video
          ref={videoRef}
          style={{ display: cameraOn ? 'block' : 'none' }}
          playsInline
          muted
          autoPlay
          onLoadedMetadata={() => videoRef.current?.play?.().catch(() => undefined)}
        />
        {!cameraOn && !previewUrl && (
          <div className="np-camera-empty">
            <Camera size={42} color="#CCFF00" style={{ opacity: 0.72 }} />
            <p>Open the camera or pick an image from your gallery.</p>
          </div>
        )}
        {busy && (
          <div className="np-camera-overlay">
            <Loader2 size={32} color="#CCFF00" className="spin" style={{ animation: 'spin 1s linear infinite' }} />
            <span>Estimating portions & macros…</span>
          </div>
        )}
      </div>

      {scanFailed && (
        <div className="mt-4 rounded-2xl border border-[#FF3B30]/35 bg-[#FF3B30]/10 p-4">
          <p className="text-sm font-black text-white">Scan unavailable right now</p>
          <p className="mt-1 text-xs leading-5 text-white/55">
            Our AI is under heavy load or couldn&apos;t read this photo. You can try again or pick a food from the
            Nutrition Bank below.
          </p>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={resetScan}
              className="rounded-xl bg-[#CCFF00] py-3 text-xs font-black text-black"
            >
              Try Again
            </button>
            <button
              type="button"
              onClick={scrollToDatabase}
              className="rounded-xl border border-white/10 bg-white/[0.06] py-3 text-xs font-black text-white/70"
            >
              Search Food Database
            </button>
          </div>
        </div>
      )}

      {result && (
        <div className="mt-4 space-y-3">
          <p className="text-sm font-black text-white">{result.mealDescription || result.food_name}</p>
          <p className="text-xs text-white/45">Total visible portion: {result.estimated_total_weight_g}g</p>

          {Array.isArray(result.items) &&
            result.items.map(item => (
              <FoodItemCard key={`${item.name}-${item.estimatedWeight}`} item={item} />
            ))}

          <div className="rounded-2xl border border-[#CCFF00]/40 bg-[#CCFF00]/10 p-4">
            <p className="text-xs font-black uppercase tracking-[0.14em] text-[#CCFF00]">Combined Total</p>
            <p className="mt-2 text-lg font-black text-white">{result.calculated_total_calories} kcal</p>
            <MacroResult label="Protein" value={`${result.calculated_total_protein_g}g`} pct={result.protein_pct} />
            <MacroResult label="Carbs" value={`${result.calculated_total_carbs_g}g`} pct={result.carbs_pct} />
            <MacroResult label="Fat" value={`${result.calculated_total_fat_g}g`} pct={result.fat_pct} />
          </div>

          <p className="text-xs font-bold text-[#CCFF00]">Coach: {coachTip}</p>
          {saveStatus && <p className="text-xs font-bold text-white/50">{saveStatus}</p>}
          <div className="grid grid-cols-2 gap-2">
            <button type="button" onClick={() => void logMeal()} className="rounded-xl bg-[#CCFF00] py-3 text-xs font-black text-black">
              Log This Meal
            </button>
            <button type="button" onClick={resetScan} className="rounded-xl border border-white/10 bg-white/[0.06] py-3 text-xs font-black text-white/60">
              Re-scan
            </button>
          </div>
        </div>
      )}

      <div className="np-btn-row" style={{ marginTop: 12 }}>
        <button type="button" className="np-btn-primary" onClick={cameraOn ? onShutter : startCamera} disabled={busy}>
          {busy ? <Loader2 size={18} style={{ animation: 'spin 1s linear infinite' }} /> : <Camera size={18} />}
          {cameraOn ? 'Analyze' : 'Open camera'}
        </button>
        <label className="np-btn-outline">
          <ImagePlus size={18} />
          Gallery
          <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={onFile} disabled={busy} style={{ display: 'none' }} />
        </label>
        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={onFile}
          disabled={busy}
          style={{ display: 'none' }}
          aria-hidden="true"
        />
      </div>
    </GlassCard>
  );
}

function FoodItemCard({ item }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-[#0A0A0A] p-4">
      <div className="flex items-start justify-between gap-2">
        <p className="text-sm font-black text-white">{item.name}</p>
        <span className="rounded-full border border-white/10 px-2 py-0.5 text-[10px] font-black uppercase text-white/45">
          {item.confidence}
        </span>
      </div>
      <p className="mt-1 text-xs text-white/45">
        ~{item.estimatedWeight}
        {item.weightUnit || 'g'} total portion (not per 100g)
      </p>
      <p className="mt-2 text-xs text-white/65">
        {item.calories} kcal · P{item.protein}g · C{item.carbs}g · F{item.fat}g
      </p>
    </div>
  );
}

function MacroResult({ label, value, pct }) {
  const width = Math.min(100, Math.max(0, Number(pct) || 0));
  return (
    <div className="mt-3 grid grid-cols-[80px_70px_1fr] items-center gap-2 text-xs">
      <span className="font-bold text-white/55">{label}</span>
      <strong className="text-white">{value}</strong>
      <span className="h-2 overflow-hidden rounded-full bg-white/10">
        <span className="block h-full rounded-full bg-[#CCFF00]" style={{ width: `${width}%` }} />
      </span>
    </div>
  );
}
